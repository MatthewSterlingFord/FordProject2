Grading Information:
	- David mount gave me an 1 week extention so this submission is on time. IE no late penatiy.	

Game Controls:
	-        Change between camera modes:        m, M
	-                            restart:        r  
	-   Move LEFT and Continuos LEFT OFF:        left arrow
	-                  Continuos LEFT ON:        a, A 
	- Move RIGHT and Continuos RIGHT OFF:        right arrow
	-                 Continuos RIGHT ON:        d, D
	-       Move UP and Continuos UP OFF:        up arrow
	-                    Continuos UP ON:        w, W 
	-   Move DOWN and Continuos DOWN OFF:        down arrow
	-                  Continuos DOWN ON:        s, S
        - Fly Up                            :        h, H  
        - Fly down                          :        l, L 
	- Rotate character positon          :        Left mouse Click and drag while holding down


Notes:
	-If errors while building remove the following line as its a nonstandard function.  
	 "glutSpecialFunc(pressSpecialKey); // process special key pressed"

	-Based off of the snow man example. 
	-Using the imageloader class and header to import texture from:http://www.videotutorialsrock.com/opengl_tutorial/cube/video.php. 


Summery:

Turtle moves left right and up and down AND FLY in all camera modes. 

In Above camera mode he will allow be set to the direction he is moving in automaticly, 
while in behind camera mode and first person camera mode his direction is only chnaged 
when the left mouses botton is clicked and held.
