Project 2 Resources
-------------------

Sample Program
--------------
Windows-Executable/TommyTerp.exe - Windows executable

Sample Video
------------
I've created a low-resolution screen capture, which I've uploaded to
youtube:

  http://youtu.be/s2sa2uiomRM

Utility Code
------------
Contains code for some useful utilities I wrote. Use if you like, but
at your own risk.

parameters.txt
--------------
A number of numeric quantities used in our implementation of the
program. You may use these, but you are encouraged to experiment with
your own settings.
